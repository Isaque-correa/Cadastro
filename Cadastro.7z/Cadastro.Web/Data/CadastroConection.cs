﻿using System.Data;
using Microsoft.Data.SqlClient;


namespace Cadastro.Web.Data
{
    public class CadastroConection
    {
        private readonly string? _connectionString;

        public CadastroConection(IConfiguration configuration)
        {
            string bancoDados = Path.Combine(AppContext.BaseDirectory, "Data\\Cadastro.mdf");
            _connectionString = configuration.GetConnectionString("CadastroConnection");
            _connectionString = _connectionString.Replace("{DynamicPath}", bancoDados);
        }
        public IDbConnection GetDbConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
